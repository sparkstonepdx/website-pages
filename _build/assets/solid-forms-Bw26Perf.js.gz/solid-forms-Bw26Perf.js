import{M as s}from"./index-CN6eFHfq.js";import{b as t,m as a}from"./solid-DeR8Uan2.js";import"./web-WrX6vF6Z.js";const r=[{title:"The Problem: Complex Tools for Simple Tasks",href:"#the-problem-complex-tools-for-simple-tasks",children:[]},{title:"The Solution: Solid Forms",href:"#the-solution-solid-forms",children:[]},{title:"Privacy First",href:"#privacy-first",children:[]},{title:"Try It Now",href:"#try-it-now",children:[]}],n={title:"solid forms",rank:null,created:"2025-12-18",published:"2025-12-18",thumbnail:null,blurb:"Simple, Shareable Forms Built for Real People"};function i(o){const e={a:"a",blockquote:"blockquote",h3:"h3",li:"li",p:"p",ul:"ul",...s(),...o.components};return[t(e.p,{children:"Sometimes you just need to ask a question and get clear answers — without bloated dashboards, account juggling, or privacy compromises. That’s why we built Solid Forms."}),`
`,t(e.p,{children:"Whether you’re collecting signups, gathering feedback, or running a workshop, Solid Forms helps you create clean, reliable forms in minutes."}),`
`,t(e.blockquote,{get children(){return[`
`,t(e.p,{get children(){return["Solid Forms is live at ",t(e.a,{href:"https://solid-forms.com",children:"solid-forms.com"})]}}),`
`]}}),`
`,t(e.h3,{id:"the-problem-complex-tools-for-simple-tasks",get children(){return t(e.a,{"data-auto-heading":"",href:"#the-problem-complex-tools-for-simple-tasks",children:"The Problem: Complex Tools for Simple Tasks"})}}),`
`,t(e.p,{children:"Most form builders pack in features you don’t need, inject trackers by default, or create a maze of permissions and settings just to get started. If you’re looking for something straightforward, that can feel like overkill."}),`
`,t(e.h3,{id:"the-solution-solid-forms",get children(){return t(e.a,{"data-auto-heading":"",href:"#the-solution-solid-forms",children:"The Solution: Solid Forms"})}}),`
`,t(e.p,{children:"Solid Forms focuses on doing the basics well. You create an account, build your form with a simple, dark-mode editor, and share it using a unique link."}),`
`,t(e.p,{children:"Add text fields, checkboxes, dropdowns, number inputs, and rich text sections. Whatever you need to get clear responses. When people fill it out, their answers appear instantly in a clean, sortable table you can export at any time."}),`
`,t(e.p,{children:"There’s no publish step, no complex visibility settings. Just build, share the link, and you’re good to go."}),`
`,t(e.p,{children:"Who It’s For"}),`
`,t(e.ul,{get children(){return[`
`,t(e.li,{children:"Builders and small teams who need feedback fast"}),`
`,t(e.li,{children:"Teachers and coaches gathering input or reflections"}),`
`,t(e.li,{children:"Workshop hosts managing signups and RSVPs"}),`
`,t(e.li,{children:"Anyone tired of bloated form tools and over-complicated platforms"}),`
`]}}),`
`,t(e.h3,{id:"privacy-first",get children(){return t(e.a,{"data-auto-heading":"",href:"#privacy-first",children:"Privacy First"})}}),`
`,t(e.p,{children:"Respondents don’t need accounts to reply. Solid Forms doesn’t track them, inject analytics, or set cookies. Responses are stored securely and stay private."}),`
`,t(e.h3,{id:"try-it-now",get children(){return t(e.a,{"data-auto-heading":"",href:"#try-it-now",children:"Try It Now"})}}),`
`,t(e.p,{get children(){return["Get started at ",t(e.a,{href:"solid-forms.com",children:"solid-forms.com"}),". It’s fast, focused, and designed to respect your time and your audience."]}}),`
`,t(e.p,{children:"Have questions or want help setting up your first form? We’re happy to walk you through it."})]}function u(o={}){const{wrapper:e}={...s(),...o.components};return e?t(e,a(o,{get children(){return t(i,o)}})):i(o)}const l={frontmatter:typeof n<"u"?n??{}:{},toc:typeof r<"u"?r:void 0,editLink:"",lastUpdated:1775189072e3};typeof window<"u"&&(window.$$SolidBase_page_data??={},window.$$SolidBase_page_data["/home/runner/work/website-src/website-src/src/routes/project/solid-forms.md"]=l);const p=l;export{p as $$SolidBase_page_data,u as default,n as frontmatter};
